-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 30, 2021 at 11:15 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dsi`
--

-- --------------------------------------------------------

--
-- Table structure for table `myapp_data`
--

CREATE TABLE `myapp_data` (
  `id` bigint(20) NOT NULL,
  `link` varchar(500) NOT NULL,
  `details` varchar(500) NOT NULL,
  `imagename` varchar(20) NOT NULL,
  `price` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `myapp_data`
--

INSERT INTO `myapp_data` (`id`, `link`, `details`, `imagename`, `price`) VALUES
(1, 'https://www.amazon.com/Ergonomic-Aluminum-Computer-Detachable-Compatible/dp/B08MV7M34D/ref=sr_1_9?dchild=1&keywords=amazonbasics&pd_rd_r=0a70cc11-c68f-4436-ac66-51e0b4eb3e29&pd_rd_w=Sd9yU&pd_rd_wg=x7RXs&pf_rd_p=9349ffb9-3aaa-476f-8532-6a4a5c3da3e7&pf_rd_r=62HYX0S45AER98C8RR2S&qid=1624996628&rnid=2941120011&s=pc&sr=1-9', 'Laptop Stand, Ergonomic Aluminum Computer Stand for Desk,Protable Detachable Laptop Riser Holder Compatible with MacBook Pro Air,Dell, HP, Lenovo,Samsung,10-15\'\' Notebook Stand', 'image1.jpg', '$17.98'),
(2, 'https://www.amazon.com/AmazonBasics-Premium-Single-Monitor-Stand/dp/B00MIBN16O/ref=sr_1_11?dchild=1&keywords=amazonbasics&pd_rd_r=0a70cc11-c68f-4436-ac66-51e0b4eb3e29&pd_rd_w=Sd9yU&pd_rd_wg=x7RXs&pf_rd_p=9349ffb9-3aaa-476f-8532-6a4a5c3da3e7&pf_rd_r=62HYX0S45AER98C8RR2S&qid=1624996628&rnid=2941120011&s=pc&sr=1-11', 'Amazon Basics Premium Single Monitor Stand - Lift Engine Arm Mount, Aluminum - Black ', 'image2.jpg', '$116.00'),
(3, 'https://www.amazon.com/AmazonBasics-8-Outlet-Surge-Protector-6-Foot/dp/B07GFRKSXD/ref=sr_1_24?dchild=1&keywords=amazonbasics&pd_rd_r=0a70cc11-c68f-4436-ac66-51e0b4eb3e29&pd_rd_w=Sd9yU&pd_rd_wg=x7RXs&pf_rd_p=9349ffb9-3aaa-476f-8532-6a4a5c3da3e7&pf_rd_r=62HYX0S45AER98C8RR2S&qid=1624996628&rnid=2941120011&s=pc&sr=1-24', 'Amazon Basics 8-Outlet Power Strip Surge Protector | 4,500 Joule, 6-Foot Cord', 'image3.jpg', '$16.99'),
(4, 'https://www.amazon.com/AmazonBasics-Slot-Phone-Mount-Holder/dp/B083KR68JW/ref=sr_1_26?dchild=1&keywords=amazonbasics&pd_rd_r=0a70cc11-c68f-4436-ac66-51e0b4eb3e29&pd_rd_w=Sd9yU&pd_rd_wg=x7RXs&pf_rd_p=9349ffb9-3aaa-476f-8532-6a4a5c3da3e7&pf_rd_r=62HYX0S45AER98C8RR2S&qid=1624997482&s=electronics&sr=1-26', 'Amazon Basics CD Slot Car Phone Mount Holder', 'image4.jpg', '$9.65'),
(5, 'https://www.amazon.com/Samsung-U32J590-32-Inch-LED-Lit-Monitor/dp/B07CS3JGPC/ref=pd_rhf_se_s_pd_crcd_4/141-6940487-9656251?pd_rd_w=o6tw7&pf_rd_p=ecb2692f-0365-4eca-a102-58ef51a608ce&pf_rd_r=26EJQC5WZA643F23Q562&pd_rd_r=0dd3c498-4dd8-442d-b1af-962a3893c850&pd_rd_wg=kkYBt&pd_rd_i=B07CS3JGPC&psc=1', 'SAMSUNG 32 inch UJ59 4k monitor (LU32J590UQNXZA) - UHD, 3840 x 2160p, 60hz, 4ms, Dual monitor, laptop monitor, monitor stand / riser / mount compliant, AMD FreeSync, Gaming, HDMI, DP, Black', 'image5.jpg', '$303.99'),
(6, 'https://www.amazon.com/Garmin-Smartwatch-Touchscreen-Monitoring-010-02173-11/dp/B07WLN9RYD/ref=sr_1_1?dchild=1&qid=1624998029&s=fashion-mens-intl-ship&sr=1-1', 'Garmin 010-02173-11 Venu, GPS Smartwatch with Bright Touchscreen Display, Features Music, Body Energy Monitoring, Animated Workouts, Pulse Ox Sensor and More, Black', 'image6.jpg', '$289.98'),
(7, 'https://www.amazon.com/Fossil-Quartz-Stainless-Steel-Chronograph/dp/B008AXYWHQ/ref=sr_1_10?dchild=1&qid=1624998091&s=fashion-mens-intl-ship&sr=1-10', 'Fossil Men\'s Nate Stainless Steel Quartz Chronograph Watch ', 'image7.jpg', '$99.00'),
(8, 'https://www.amazon.com/PUMA-Surin-Sneaker-Charcoal-White/dp/B07MTJSV7L/ref=sr_1_48?dchild=1&pf_rd_i=16225019011&pf_rd_m=ATVPDKIKX0DER&pf_rd_p=554625a3-8de1-4fdc-8877-99874d353388&pf_rd_r=3SDJ9EQWD79ND7HBZGQ4&pf_rd_s=merchandised-search-4&pf_rd_t=101&qid=1624998171&s=fashion-mens-intl-ship&sr=1-48', 'PUMA Men\'s Cell Surin 2.0 FM Sneaker', 'image8.jpg', '$59.83 - $185.0'),
(9, 'https://www.amazon.com/Ray-Ban-RB3025-Aviator-Sunglasses-Black/dp/B000GLN15O/ref=sr_1_4?dchild=1&pf_rd_i=16225019011&pf_rd_m=ATVPDKIKX0DER&pf_rd_p=554625a3-8de1-4fdc-8877-99874d353388&pf_rd_r=3SDJ9EQWD79ND7HBZGQ4&pf_rd_s=merchandised-search-4&pf_rd_t=101&qid=1624998340&s=fashion-mens-intl-ship&sr=1-4', 'Ray-Ban Rb3025 Classic Mirrored Aviator Sunglasses ', 'image9.jpg', '$112.70'),
(10, 'https://www.amazon.com/dp/B0875FRJPT/ref=s9_acsd_al_bw_c2_x_3_t?pf_rd_m=ATVPDKIKX0DER&pf_rd_s=merchandised-search-4&pf_rd_r=Y24807MCAAK670M355DZ&pf_rd_t=101&pf_rd_p=07d3dcde-01c7-42e2-b4bf-80eb5a972100&pf_rd_i=21217033011', 'Arlo Essential Spotlight Camera - 1 Pack - Wireless Security, 1080p Video, Color Night Vision, 2 Way Audio, Wire-Free, Direct to WiFi No Hub Needed, Works with Alexa, White - VMC2030 ', 'image10.jpg', '$99.99');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `myapp_data`
--
ALTER TABLE `myapp_data`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `myapp_data`
--
ALTER TABLE `myapp_data`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
