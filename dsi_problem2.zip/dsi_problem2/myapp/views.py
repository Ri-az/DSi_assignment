from django.shortcuts import render
from .models import *

# Create your views here.
def homeview(httprequest):
    try:
        result = Data.objects.values()
    except:
        result=""
    print(result)
    return render(httprequest,'home.html',context={"allLinks":result})
