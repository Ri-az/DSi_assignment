from django.db import models

# Create your models here.
class Data(models.Model):
    link = models.CharField(max_length=500)
    details = models.CharField(max_length=500)
    imagename = models.CharField(max_length=20)
    price=models.CharField(max_length=15)

