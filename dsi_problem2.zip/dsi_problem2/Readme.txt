For windows environment

step 1: Install the python and open the command prompt

step 2: Type the following command to create virtual environment
		> python -m venv virtual_environment_name

step 3: Copy the project folder "dsi_problem2" and requirements.txt
		and paste it within the "virtual_environment_name" folder

step 4: Then go within the folder 
		> cd virtual_environment_name

step 5: To activate the virtual environment type the command
		> Scripts\activate.bat
		> cd dsi_problem2

step 6: To setup all the required packages run the following command
		> python -m pip install -r requirements.txt
		
step 7: Then open xampp and create a mysql database named "dsi"

step 8: Then import the myapp_data.sql table in the dsi datatabase 

step 9: Then run the following commands sequentially
		> python manage.py makemigrations
		> python manage.py migrate
		> python manage.py runserver
		
step 10: Open the browser and visit
		http://localhost:8000/home/